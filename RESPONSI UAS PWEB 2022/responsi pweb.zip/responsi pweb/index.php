<?php $halaman = "Nanda's.CO Donuts & Coffee" ?>

<?php
class File
{
  public static function newFilename()
  {
    return time();
  }

  public static function getExt($fileName)
  {
    $ext = explode(".", $fileName);
    return "." . $ext[count($ext) - 1];
  }

  public static function saveFile($files, $newName)
  {
    if (count($files) == 1) {
      $tmp_address = '';
      foreach ($files as $key => $value) {
        $tmp_address = $value['tmp_name'];
      }

      if (move_uploaded_file($tmp_address, $newName)) {
        return 1;
      } else {
        return 0;
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <title><?= $halaman ?></title>
</head>

<body>

  <?php
  $myfile = fopen("App/data/barang.txt", "r") or die("Unable to open file!");
  $data = fread($myfile, filesize("App/data/barang.txt"));
  fclose($myfile);
  $shoes = json_decode($data, true);
  ?>



  <style>
    .shadow-sm {
      box-shadow: 0px 3px 5px rgba(0, 0, 0, .15);
    }

    footer {
      text-align: center;
    }

    @media (max-width: 576px) {
      .card-title {
        font-size: 14px;
      }

      .card-text {
        font-size: 12px;
      }

      footer p {
        font-size: 10px;
      }
    }
  </style>
  <nav class="navbar navbar-expand-lg navbar-dark shadow fixed-top" style="background: orange;">
    <div class="container">
      <!-- <a class="navbar-brand" href="#">SEPATU WARRIOR</a> -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav mx-auto my-auto">
          <a class="nav-item nav-link" href="index.php">Beranda</a>
          <a href="index.php" class="text-white ml-3 mr-3" style="transform: translateY(3px);">
            <h4 class="fw-bolder" style="text-transform: uppercase;">Nanda's.CO</h4>
          </a>
          <a class="nav-item nav-link" href="admin/login.php">Login</a>
          <a class="nav-item nav-link" href="">Checkout</a>
        </div>
      </div>
    </div>
  </nav>

  <style>
    .jumbotron {
      height: 550px;
      background: url('assets/img/latar.jpg');
      background-size: cover;
      background-position: 0px -300px;
    }

    .jumbotron h2,
    .jumbotron h5 {
      text-shadow: 0px 3px 5px rgba(0, 0, 0, 0.35);
    }
  </style>

  <div class="jumbotron border mt-5">
    <div class="container pt-5 text-center">
      <h2 class="display-4 text-white mb-3">Nanda's.CO</h2>
      <p class="text-white mb-4" style="width: 400px; margin: auto;">Selamat datang di Nanda's Doughnuts. Silahkan berbelanja sesuka hati kalian, dan scroll kebawah untuk melihat daftar menu saya! Terima kasih selamat menikmati :) </p>
      <a href="#produk" class="btn text-white btn-warning">Pesang Sekarang</a>
    </div>
  </div>

  <!-- content -->
  <section class="main mt-4 pt-4" id="produk " style="min-height: 88vh;">
    <div class="container">
      <h5 class="mb-4 pb-3">Produk Terbaru</h5>
      <div class="row">

        <?php if ($shoes) : ?>

          <?php foreach ($shoes as $item) : ?>
            <div class="col-md-3 col-6 mb-4">
              <div class="card shadow-sm border-0">
                <img class="card-img-top" src="assets/img/<?= $item['image'] ?>" alt="Card image cap">
                <div class="card-body">
                  <h6 class="card-title"><?= $item['name'] ?></h6>
                  <p class="text-secondary">Rp. <?= number_format($item['price']) ?></p>
                  <a href="beli.php?id=<?= $item['id'] ?>" class="btn btn-info btn-sm pl-3 pr-3"><i class="fa-solid fa-plus"></i> Beli</a>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>

      </div>
    </div>
  </section>
  <!-- endContent -->

  <footer class="pt-3 pb-4 bg-light">
    <p class="mb-0 text-secondary">copyright 2022 | build by <a href="" class="text-info">Ananda Firdaus</a></p>
  </footer>

</body>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</html>