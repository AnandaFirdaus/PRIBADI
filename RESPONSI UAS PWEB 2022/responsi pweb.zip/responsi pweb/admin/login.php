<?php
class File
{
  public static function newFilename()
  {
    return time();
  }

  public static function getExt($fileName)
  {
    $ext = explode(".", $fileName);
    return "." . $ext[count($ext) - 1];
  }

  public static function saveFile($files, $newName)
  {
    if (count($files) == 1) {
      $tmp_address = '';
      foreach ($files as $key => $value) {
        $tmp_address = $value['tmp_name'];
      }

      if (move_uploaded_file($tmp_address, $newName)) {
        return 1;
      } else {
        return 0;
      }
    }
  }
}

function clear($data)
{
  return htmlspecialchars($data);
}

$err = false;
$succ = false;

if (isset($_POST['login'])) {
  $data = [
    "username" => clear($_POST['username']),
    "password" => clear($_POST['password']),
  ];

  $myfile = fopen("../App/data/admin.txt", "r") or die("Unable to open file!");
  $dataAdmin = json_decode(fread($myfile, filesize("../App/data/admin.txt")), true);
  fclose($myfile);

  if ($dataAdmin['username'] == $data['username'] && $dataAdmin['password'] == $data['password']) {
    session_start();
    $_SESSION['login'] = "admin";
    $succ = true;
  } else {
    $err = true;
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Login - Nanda's.CO</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon">

  <!-- Google Web Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">


  <!-- Customized Bootstrap Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Template Stylesheet -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>
  <div class="container-xxl position-relative bg-white d-flex p-0">

    <!-- Sign In Start -->
    <div class="container-fluid">
      <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
        <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
          <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">
            <div class="d-flex align-items-center justify-content-between mb-3">
              <!-- <a href="index.html" class="">
                                <h3 class="text-primary"><i class="fa fa-hashtag me-2"></i>DASHMIN</h3>
                            </a> -->
              <h3>Login</h3>
            </div>
            <form action="" method="post">
              <?php if ($err) : ?>
                <p class="text-center text-danger"><small>Username/Password Salah</small></p>
              <?php endif; ?>
              <div class="form-floating mb-3">
                <input type="text" name="username" class="form-control" id="floatingInput" placeholder="Username">
                <label for="floatingInput">Username</label>
              </div>
              <div class="form-floating mb-4">
                <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
                <label for="floatingPassword">Password</label>
              </div>

              <button type="submit" name="login" class="btn btn-primary py-3 w-100 mb-4">Sign In</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- Sign In End -->
  </div>

  <?php if ($succ) : ?>
    <script>
      alert('Berhasil Login!');
      setTimeout(() => {
        location.replace('index.php');
      }, 1500);
    </script>
  <?php endif; ?>

  <!-- Template Javascript -->
  <script src="js/main.js"></script>
</body>

</html>