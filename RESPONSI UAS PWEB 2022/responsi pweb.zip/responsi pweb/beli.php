<?php
class File
{
  public static function newFilename()
  {
    return time();
  }

  public static function getExt($fileName)
  {
    $ext = explode(".", $fileName);
    return "." . $ext[count($ext) - 1];
  }

  public static function saveFile($files, $newName)
  {
    if (count($files) == 1) {
      $tmp_address = '';
      foreach ($files as $key => $value) {
        $tmp_address = $value['tmp_name'];
      }

      if (move_uploaded_file($tmp_address, $newName)) {
        return 1;
      } else {
        return 0;
      }
    }
  }
}

function clear($data)
{
  return htmlspecialchars($data);
}

$halaman = "Checkout";

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <title><?= $halaman ?></title>
</head>

<body>

  <?php
  $alert;


  if (isset($_POST["checkout"])) {

    $myfile = fopen("App/data/orderan.txt", "r") or die("Unable to open file!");
    $data = fread($myfile, filesize("App/data/orderan.txt"));
    fclose($myfile);
    $orderan = json_decode($data, true);

    if ($orderan) {
      $id = 1 + (int) $orderan[count($orderan) - 1]['id'];
    } else {
      $id = 0;
    }

    $data = [
      "id" => $id,
      "name" => clear($_POST['name']),
      "address" => clear($_POST['address']),
      "product" => clear($_POST['product']),
      "amount" => clear($_POST['amount']),
      "price" => clear($_POST['price']),
      "date_order" => date("d M Y"),
    ];

    $orderan[] = $data;

    $myfile = fopen("App/data/orderan.txt", "w") or die("Unable to open file!");
    $txt = json_encode($orderan);
    fwrite($myfile, $txt);
    fclose($myfile);

    $alert["checkout"] = true;
  }

  $myfile = fopen("App/data/barang.txt", "r") or die("Unable to open file!");
  $data = fread($myfile, filesize("App/data/barang.txt"));
  fclose($myfile);
  $shoes = json_decode($data, true);

  $sepatu = [];
  $id = clear($_GET['id']);

  foreach ($shoes as $item) {
    if ($item['id'] == $id) {
      $sepatu = $item;
    }
  }

  ?>

  <nav class="navbar navbar-expand-lg navbar-dark shadow fixed-top" style="background: orange;">
    <div class="container">
      <!-- <a class="navbar-brand" href="#">SEPATU WARRIOR</a> -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav mx-auto my-auto">
          <a class="nav-item nav-link" href="index.php">Beranda</a>
          <a href="index.php" class="text-white ml-3 mr-3" style="transform: translateY(3px);">
            <h4 class="fw-bolder" style="text-transform: uppercase;">Nanda's.CO</h4>
          </a>
          <a class="nav-item nav-link" href="admin/login.php">Login</a>
          <a class="nav-item nav-link" href="">Checkout</a>
        </div>
      </div>
    </div>
  </nav>

  <style>
    .shadow-sm {
      box-shadow: 0px 3px 5px rgba(0, 0, 0, .15);
    }
  </style>

  <section class="main mt-3 pt-5">

    <div class="container">
      <h2 class="mb-4">Keranjang Belanja</h2>
      <div class="card shadow-sm border-0">
        <div class="card-body">
          <table class="table border-0">
            <thead class="bg-light">
              <tr>
                <th scope="col">Produk</th>
                <th scope="col">Harga</th>
                <th scope="col">Jumlah</th>
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>

              <?php if (isset($_GET['id'])) : ?>
                <td><?= $sepatu['name'] ?></td>
                <td>Rp<?= number_format($sepatu['price']) ?></td>
                <td><button class="btn btn-sm btn-info" onclick="kurang()">
                    <</button> <button class="btn btn-sm btn-outline-info show-jumlah">1
                  </button> <button class="btn btn-sm btn-info" onclick="tambah()">
                    ></button></td>
                <td>Rp<span class="total"><?= $sepatu['price'] ?></span></td>
              <?php endif; ?>

            </tbody>
          </table>

          <form action="" method="post">
            <div class="form-group">
              <div class="row">
                <div class="col-md-4">
                  <input type="text" class="form-control form-control-user" id="user" name="name" aria-describedby="emailHelp" value="" autocomplete="off" placeholder="Nama" name="name">
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control form-control-user" id="user" name="address" aria-describedby="emailHelp" value="" autocomplete="off" name="address" placeholder="Alamat">
                </div>
                <input type="hidden" name="product" value="<?= $sepatu['name'] ?>">
                <input type="hidden" class="input-amount" name="amount" value="1">
                <input type="hidden" name="price" value="<?= $sepatu['price'] ?>">

              </div>
              <button type="submit" name="checkout" class="btn btn-warning btn-sm mt-3 text-white">Checkout</button>
            </div>
          </form>
        </div>
      </div>

    </div>
  </section>

  <script>
    let price = <?= $sepatu['price'] ?>;
    let jumlah = 1;
    let tableTotal = document.querySelector('.total');
    let inputAmount = document.querySelector('.input-amount');
    let showJumlah = document.querySelector('.show-jumlah');

    let tambah = () => {
      jumlah++;

      tableTotal.innerHTML = price * jumlah;
      inputAmount.value = jumlah;
      showJumlah.innerHTML = jumlah;
    }

    let kurang = () => {
      if (jumlah > 1) {
        jumlah--;

        tableTotal.innerHTML = price * jumlah;
        inputAmount.value = jumlah;
        showJumlah.innerHTML = jumlah;
      }
    }
  </script>

</body>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</html>

<?php

if (isset($alert["checkout"])) {
  if ($alert["checkout"]) {
    echo '<script>swal("Order Berhasil", "", "success");</script>';
    echo "<script>setTimeout(() => {
        window.location.href = 'index.php';
      }, 1500)</script>";
  }
}

?>